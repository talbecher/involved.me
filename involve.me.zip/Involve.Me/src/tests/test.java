package tests;

public @interface test {

}
